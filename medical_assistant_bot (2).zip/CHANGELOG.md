# Changelog

## 2025-08-28
- Rename model class to `MedQARetriever`
- Add low-confidence threshold to avoid overconfident answers
- CLI/help text cleanup, README tweaks
- Add Makefile, CONTRIBUTING.md, .editorconfig, and pyproject.toml
