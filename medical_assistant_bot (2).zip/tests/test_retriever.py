import pandas as pd
from src.medical_bot import MedQARetriever

def test_fit_and_generate():
    data = pd.DataFrame({
        "question": ["What is flu?", "How to treat flu?", "Symptoms of flu?"],
        "answer": ["Flu is influenza.", "Rest and fluids.", "Fever, cough, aches."]
    })
    bot = MedQARetriever(k=2).fit(data)
    out = bot.generate("What are flu symptoms?")
    assert "answer" in out
    assert isinstance(out["evidence"], list)
