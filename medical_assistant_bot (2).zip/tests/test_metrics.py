import math
from src.metrics import bleu_score, rouge_l, tfidf_cosine

def test_bleu_basic():
    ref = "fever and cough are common"
    hyp = "cough and fever are common"
    assert bleu_score(ref, hyp) > 0.1

def test_rouge_basic():
    ref = "shortness of breath and chest pain"
    hyp = "chest pain with shortness of breath"
    assert rouge_l(ref, hyp) > 0.3

def test_tfidf_cosine_symmetry():
    a = "aspirin is used for pain relief"
    b = "pain relief often uses aspirin"
    s1 = tfidf_cosine(a, b)
    s2 = tfidf_cosine(b, a)
    assert abs(s1 - s2) < 1e-6
