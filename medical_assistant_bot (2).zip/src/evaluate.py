
import pandas as pd
from .medical_bot import MedicalQABot
from .metrics import bleu_score, rouge_l, tfidf_cosine

def evaluate(bot: MedicalQABot, df: pd.DataFrame):
    rows = []
    for _, row in df.iterrows():
        pred = bot.generate(row["question"])
        y_true = row["answer"]
        y_pred = pred["answer"]
        rows.append({
            "bleu": bleu_score(y_true, y_pred),
            "rouge_l": rouge_l(y_true, y_pred),
            "tfidf_cosine": tfidf_cosine(y_true, y_pred)
        })
    if not rows:
        return {"bleu":0.0, "rouge_l":0.0, "tfidf_cosine":0.0}
    dfm = pd.DataFrame(rows)
    return {
        "bleu": float(dfm["bleu"].mean()),
        "rouge_l": float(dfm["rouge_l"].mean()),
        "tfidf_cosine": float(dfm["tfidf_cosine"].mean())
    }
