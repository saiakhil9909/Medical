class DataFormatError(Exception):
    """Raised when the dataset does not have the expected columns."""

class ModelNotFittedError(Exception):
    """Raised when an operation requires a fitted model."""
