import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

def setup_logging(log_file: str | None = None, level: int = logging.INFO) -> None:
    fmt = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    handlers = [logging.StreamHandler()]
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        handlers.append(RotatingFileHandler(log_file, maxBytes=1_000_000, backupCount=3))
    logging.basicConfig(level=level, format=fmt, handlers=handlers)
