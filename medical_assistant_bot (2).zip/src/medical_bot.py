
"""
Compact retrieval model for medical Q&A.
Notes:
- Focus is on clarity and predictable behavior.
- If the nearest neighbor similarity is too low, the model will say it doesn't know.
"""

import re
import pickle
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

_WS = re.compile(r"\s+")

def normalize_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.strip().lower()
    return _WS.sub(" ", text)

@dataclass
class RetrievalHit:
    score: float
    train_question: str
    train_answer: str

class MedQARetriever:
    """
    TF‑IDF + cosine k-NN retriever.
    - Fits on training questions
    - Returns the majority-voted answer among top-k hits
    - If top similarity < `min_conf`, returns an empty answer
    """

    def __init__(self, k: int = 3, min_conf: float = 0.2) -> None:
        self.k = k
        self.min_conf = min_conf
        self.vectorizer: Optional[TfidfVectorizer] = None
        self.nn: Optional[NearestNeighbors] = None
        self.qa_df: Optional[pd.DataFrame] = None
        self._X = None  # TF‑IDF matrix of normalized questions

    def fit(self, df: pd.DataFrame) -> "MedQARetriever":
        assert {"question", "answer"}.issubset(df.columns), "Expected columns: question, answer"
        data = df.copy()
        data["question_norm"] = data["question"].apply(normalize_text)
        data = data.drop_duplicates(subset=["question_norm"]).reset_index(drop=True)

        self.qa_df = data[["question", "question_norm", "answer"]]
        self.vectorizer = TfidfVectorizer(min_df=2, ngram_range=(1, 2))
        self._X = self.vectorizer.fit_transform(self.qa_df["question_norm"].tolist())

        self.nn = NearestNeighbors(metric="cosine", algorithm="brute")
        self.nn.fit(self._X)
        return self

    def retrieve(self, query: str, k: Optional[int] = None) -> List[RetrievalHit]:
        if k is None:
            k = self.k
        q_norm = normalize_text(query)
        q_vec = self.vectorizer.transform([q_norm])
        dists, idxs = self.nn.kneighbors(q_vec, n_neighbors=min(k, self._X.shape[0]))
        sims = (1 - dists[0]).tolist()
        idxs = idxs[0].tolist()

        hits: List[RetrievalHit] = []
        for s, i in sorted(zip(sims, idxs), key=lambda x: x[0], reverse=True):
            row = self.qa_df.iloc[i]
            hits.append(RetrievalHit(score=float(s), train_question=row["question"], train_answer=row["answer"]))
        return hits

    def generate(self, query: str) -> Dict[str, Any]:
        hits = self.retrieve(query, k=self.k)
        if not hits or hits[0].score < self.min_conf:
            return {"answer": "", "evidence": [], "note": "low confidence; nearest neighbor below threshold"}

        def norm(x: str) -> str: return normalize_text(x)
        counts: dict[str, int] = {}
        for h in hits:
            a = norm(h.train_answer)
            counts[a] = counts.get(a, 0) + 1
        best_norm = max(counts.items(), key=lambda kv: (kv[1], len(kv[0])))[0]
        best_original = next(h.train_answer for h in hits if norm(h.train_answer) == best_norm)
        return {"answer": best_original, "evidence": [h.__dict__ for h in hits]}

    def save(self, path: str) -> None:
        with open(path, "wb") as f:
            pickle.dump({"k": self.k, "min_conf": self.min_conf, "vectorizer": self.vectorizer, "nn": self.nn, "qa_df": self.qa_df}, f)

    @staticmethod
    def load(path: str) -> "MedQARetriever":
        with open(path, "rb") as f:
            obj = pickle.load(f)
        bot = MedQARetriever(k=obj["k"], min_conf=obj.get("min_conf", 0.2))
        bot.vectorizer = obj["vectorizer"]
        bot.nn = obj["nn"]
        bot.qa_df = obj["qa_df"]
        bot._X = bot.vectorizer.transform(bot.qa_df["question_norm"].tolist())
        return bot
