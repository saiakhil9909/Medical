
"""Evaluate a saved model on a CSV dataset (question, answer)."""
import argparse
import pandas as pd
from .medical_bot import MedQARetriever
from .metrics import bleu_score, rouge_l, tfidf_cosine

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Path to model.pkl produced by training")
    ap.add_argument("--data", required=True, help="CSV with question,answer columns")
    args = ap.parse_args()

    bot = MedQARetriever.load(args.model)
    df = pd.read_csv(args.data)
    rows = []
    for _, row in df.iterrows():
        pred = bot.generate(row["question"])
        y_true, y_pred = row["answer"], pred["answer"]
        rows.append({
            "bleu": bleu_score(y_true, y_pred),
            "rouge_l": rouge_l(y_true, y_pred),
            "tfidf_cosine": tfidf_cosine(y_true, y_pred)
        })
    m = pd.DataFrame(rows).mean().to_dict()
    print({k: round(float(v), 6) for k, v in m.items()})

if __name__ == "__main__":
    main()
