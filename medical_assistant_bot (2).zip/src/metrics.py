
"""Lightweight text generation metrics used for quick model checks."""
import math, re
from sklearn.feature_extraction.text import TfidfVectorizer

_ws = re.compile(r"\s+")

def normalize_text(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = s.strip().lower()
    return _ws.sub(" ", s)

def basic_tokenize(s: str):
    return re.findall(r"[a-z0-9]+", normalize_text(s))

def ngrams(tokens, n):
    return [tuple(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def bleu_score(reference: str, hypothesis: str, max_n: int = 4, smooth: bool = True) -> float:
    """N‑gram precision BLEU with brevity penalty and simple smoothing."""
    ref_toks = basic_tokenize(reference)
    hyp_toks = basic_tokenize(hypothesis)
    if len(hyp_toks) == 0:
        return 0.0
    precisions = []
    for n in range(1, max_n+1):
        ref_counts = {}
        for g in ngrams(ref_toks, n):
            ref_counts[g] = ref_counts.get(g, 0) + 1
        hyp_counts = {}
        for g in ngrams(hyp_toks, n):
            hyp_counts[g] = hyp_counts.get(g, 0) + 1
        overlap = sum(min(hyp_counts.get(g, 0), ref_counts.get(g, 0)) for g in hyp_counts)
        total = sum(hyp_counts.values())
        p_n = (overlap / total) if total else 0.0
        if smooth and p_n == 0.0:
            p_n = 1e-9
        precisions.append(p_n)
    ref_len, hyp_len = len(ref_toks), len(hyp_toks)
    bp = 1.0 if hyp_len > ref_len else (math.exp(1 - (ref_len / hyp_len)) if hyp_len else 0.0)
    log_prec = sum(math.log(p) for p in precisions) / max_n
    return float(bp * math.exp(log_prec))

def _lcs_len(a, b):
    m, n = len(a), len(b)
    dp = [[0]*(n+1) for _ in range(m+1)]
    for i in range(m):
        for j in range(n):
            dp[i+1][j+1] = dp[i][j] + 1 if a[i] == b[j] else max(dp[i+1][j], dp[i][j+1])
    return dp[m][n]

def rouge_l(reference: str, hypothesis: str) -> float:
    """ROUGE‑L F‑score (LCS‑based)."""
    ref, hyp = basic_tokenize(reference), basic_tokenize(hypothesis)
    if not ref or not hyp:
        return 0.0
    lcs = _lcs_len(ref, hyp)
    prec = lcs / len(hyp)
    rec = lcs / len(ref)
    if not (prec + rec):
        return 0.0
    beta2 = 1.2**2
    return float((1 + beta2) * prec * rec / (rec + beta2 * prec + 1e-12))

def tfidf_cosine(a: str, b: str) -> float:
    """Cosine similarity between TF‑IDF vectors of two strings."""
    vect = TfidfVectorizer(min_df=1)
    X = vect.fit_transform([a, b])
    v0, v1 = X[0].toarray().ravel(), X[1].toarray().ravel()
    denom = (v0 @ v0) ** 0.5 * (v1 @ v1) ** 0.5
    return float(v0.dot(v1) / denom) if denom else 0.0
