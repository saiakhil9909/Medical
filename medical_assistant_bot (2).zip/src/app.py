
import argparse
import pandas as pd
from .medical_bot import MedQARetriever

def main():
    parser = argparse.ArgumentParser(description="Medical Q&A Retriever (TF‑IDF)")
    parser.add_argument("--data", type=str, help="CSV file with columns [question, answer]", required=True)
    parser.add_argument("--model_out", type=str, default="model.pkl", help="Where to save the fitted model")
    parser.add_argument("--k", type=int, default=3, help="Top-k neighbors")
    parser.add_argument("--interactive", action="store_true", help="Run interactive chat after training")
    args = parser.parse_args()

    df = pd.read_csv(args.data)
    bot = MedQARetriever(k=args.k).fit(df)
    bot.save(args.model_out)
    print(f"Model trained. Saved to {args.model_out}. Train size: {len(df)}")

    if args.interactive:
        print("Enter medical questions (type 'exit' to quit):")
        while True:
            q = input("> ").strip()
            if q.lower() in ["exit","quit"]:
                break
            result = bot.generate(q)
            answer = result["answer"]
            print(f"Answer: {answer}")
            print("Top evidence:")
            for i, ev in enumerate(result["evidence"], start=1):
                print(f"  {i}) [score={ev['score']:.3f}] Q: {ev['train_question']} | A: {ev['train_answer']}")

if __name__ == "__main__":
    main()
