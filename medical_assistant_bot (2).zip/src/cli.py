"""Command-line interface for training, evaluation, chatting, and dataset diagnostics."""
from pathlib import Path
import json
import typer
import pandas as pd

from .medical_bot import MedQARetriever
from .metrics import bleu_score, rouge_l, tfidf_cosine
from .logging_setup import setup_logging

app = typer.Typer(add_completion=False)

@app.command()
def train(data: Path, model_out: Path = Path("model.pkl"), k: int = 3, min_conf: float = 0.2):
    """Fit the retriever on CSV with columns [question, answer] and save to MODEL_OUT."""
    setup_logging()
    df = pd.read_csv(data)
    bot = MedQARetriever(k=k, min_conf=min_conf).fit(df)
    bot.save(str(model_out))
    typer.echo(json.dumps({"model_out": str(model_out), "train_size": len(df), "k": k, "min_conf": min_conf}))

@app.command()
def evaluate(model: Path, data: Path):
    """Evaluate a saved model on a CSV dataset."""
    setup_logging()
    bot = MedQARetriever.load(str(model))
    df = pd.read_csv(data)
    rows = []
    for _, row in df.iterrows():
        pred = bot.generate(row["question"])
        y_true, y_pred = row["answer"], pred["answer"]
        rows.append({
            "bleu": bleu_score(y_true, y_pred),
            "rouge_l": rouge_l(y_true, y_pred),
            "tfidf_cosine": tfidf_cosine(y_true, y_pred)
        })
    m = pd.DataFrame(rows).mean().to_dict() if rows else {"bleu":0,"rouge_l":0,"tfidf_cosine":0}
    typer.echo(json.dumps(m, indent=2))

@app.command()
def chat(model: Path):
    """Interactive Q&A loop."""
    setup_logging()
    bot = MedQARetriever.load(str(model))
    typer.echo("Type a medical question (or 'exit' to quit).")
    while True:
        q = input('> ').strip()
        if q.lower() in {"exit","quit"}:
            break
        pred = bot.generate(q)
        if pred.get("note"):
            typer.echo(f"(low confidence)")
        typer.echo(f"Answer: {pred['answer'] or '(no answer)'}")
        for i, ev in enumerate(pred["evidence"], start=1):
            typer.echo(f"  {i}. score={ev['score']:.3f} | Q: {ev['train_question']}")

@app.command()
def diagnose(data: Path, out: Path = Path("diagnostics.json")):
    """Basic dataset diagnostics: nulls, duplicates, length stats."""
    setup_logging()
    df = pd.read_csv(data)
    info = {}
    info["rows"] = len(df)
    info["columns"] = list(df.columns)
    info["nulls"] = {c:int(df[c].isna().sum()) for c in df.columns}
    # duplicates by normalized question
    from .medical_bot import normalize_text
    if "question" in df.columns:
        qn = df["question"].astype(str).map(normalize_text)
        info["duplicate_questions"] = int(len(qn) - len(qn.drop_duplicates()))
        info["question_len_avg"] = float(qn.str.split().map(len).mean())
    Path(out).write_text(json.dumps(info, indent=2))
    typer.echo(str(out))

if __name__ == "__main__":
    app()
