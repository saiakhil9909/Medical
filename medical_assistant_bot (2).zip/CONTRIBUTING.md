# Contributing

Style notes:
- Keep functions short and specific. If a function exceeds ~40 lines, consider splitting it.
- Prefer explicit names over comments.
- Add tests for metrics if you change their logic.
- Avoid clever one-liners when a few clear lines do the job.
